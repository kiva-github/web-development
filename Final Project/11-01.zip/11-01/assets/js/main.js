function topExpand() {
  var curr = document.getElementById('productDescriptionA');
  var alt = document.getElementById('productDescriptionB');
  var alt2 = document.getElementById('productDescriptionC');
  var icon = document.getElementById('expandA');

  curr.classList.toggle("curr_active");
  alt.classList.toggle("inactiveFirst");
  alt2.classList.toggle("inactiveSecond");
  icon.classList.toggle("collapse_icon");

  setTimeout(function() {
    alt.classList.toggle ("inactiveHide");
    alt2.classList.toggle ("inactiveHide");
  }, (0.5*1000));
}

function midExpand() {
  var curr = document.getElementById('productDescriptionB');
  var alt = document.getElementById('productDescriptionA');
  var alt2 = document.getElementById('productDescriptionC');
  var icon = document.getElementById('expandB');

  curr.classList.toggle("curr_active");
  curr.classList.toggle("midActiveShift");
  alt.classList.toggle("inactiveFirst");
  alt2.classList.toggle("inactiveSecond");
  icon.classList.toggle("collapse_icon");

  setTimeout(function() {
    alt.classList.toggle ("inactiveHide");
    alt2.classList.toggle ("inactiveHide");
  }, (0.5*1000));
}

function botExpand() {
  var curr = document.getElementById('productDescriptionC');
  var alt = document.getElementById('productDescriptionA');
  var alt2 = document.getElementById('productDescriptionB');
  var icon = document.getElementById('expandC');

  curr.classList.toggle("curr_active");
  alt.classList.toggle("inactiveFirst");
  alt2.classList.toggle("inactiveSecond");
  icon.classList.toggle("collapse_icon");

  setTimeout(function() {
    alt.classList.toggle ("inactiveHide");
    alt2.classList.toggle ("inactiveHide");
  }, (0.5*1000));
}
